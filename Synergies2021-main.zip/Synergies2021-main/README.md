# Synergies2021
Hackathon
